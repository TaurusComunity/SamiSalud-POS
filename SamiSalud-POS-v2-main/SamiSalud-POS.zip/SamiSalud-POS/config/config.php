<?php

define("URL", "http://localhost:80/SamiSalud-POS");
define("HOST", "127.0.0.1");
define("DB", "samisalud");
define("USER", "root");
define("PASSWORD", "");
define("CHARSET", "utf8mb4");